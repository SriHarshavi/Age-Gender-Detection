# age_and_gender_detection
Age and Gender Detection - based on Satya Mallicks blog post on LearnOpenCV.com
